Modern Snake Game using Computer Vision which uses Color Detection, Placing PNG image over another image, checking for intersecting lines and drawing on an image. You need to have Python3 and OpenCV installed to run the program. Enjoy! Feel free to report any bugs.

